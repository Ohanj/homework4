
const triangleStars = function(height) {
  
  let i = height;
  while (i > 0) {
    
    let row = "";
    
    let j = 0;
    while (j < 2 * height - 1) {
      if (j < height - i || j > height + i - 2) {
        row += " ";
      } else {
        row += "*";
      }
      j++;
    }
    console.log(row);
    i--;
  }
};

triangleStars(4);


const multiToSingle = function(arr1, arr2) {

  let arr = [];
  let i = 0;
 
  while (i < arr1.length) {
    arr[i] = arr1[i];
    i++;
  }
 
  i = 0;

  while (i < arr2.length) {
    arr[arr1.length + i] = arr2[i];
    i++;
  }

  return arr;
};

console.log(multiToSingle([1, 2, 3], [4, 5, 6]));


const findMinMax = function(arr, isMax) {
 
  let minMax = arr[0];
  let i = 0;
  while (i < arr.length) {
    if (isMax) {
      if (arr[i] > minMax) {
        minMax = arr[i];
      }
    } else {
      if (arr[i] < minMax) {
        minMax = arr[i];
      }
    }
    i++;
  }
  
  return minMax;
};

console.log("max", findMinMax([4, 2, 66, -44, 8], true));
console.log("min", findMinMax([4, 2, 66, -44, 8], false));


const forEach = function(arr, func) {
  
  let i = 0;
  while (i < arr.length) {
    func(arr[i]);
    i++;
  }
};

forEach([4, 3, 2], function(val) {
  console.log(val);
});


const sum = function(arr) {
  
  let sum = 0;
  
  let i = 0;
  while (i < arr.length) {
    sum += arr[i];
    i++;
  }
  return sum;
};

console.log(sum([4, 3, 2]));


const reverse = function(string) {
  
  let reversed = "";
 
  let i = string.length - 1;
  while (i >= 0) {
    reversed += string[i];
    i--;
  }
  return reversed;
};

console.log(reverse("A nut for a jar of tuna"));


const checkerboard = function(size) {
  
  let i = 1;
  while (i <= size) {
    
    let j = 1;
   
    let row = "";
    while (j <= size * 2) {
      
      if (i % 2 === j % 2) {
        row += "*";
      }
      
      else {
        row += " ";
      }
      j++;
    }
    
    console.log(row);
    i++;
  }
};

checkerboard(5);
